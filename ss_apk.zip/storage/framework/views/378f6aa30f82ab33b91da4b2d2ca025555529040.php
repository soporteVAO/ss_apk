

<?php $__env->startPush('css'); ?>
<style>
    .tab-footer{
        padding: 15px 15px 10px 15px;
        background-color: transparent;
        line-height: 30px;
        border-top: none !important;
        font-size: 14px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
            <div class="content">
                <div class="container-fluid">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-8 ml-auto mr-auto">
                                <form id="wizardForm" method="post" action="<?php echo e(route('guiones.store')); ?>" novalidate="novalidate">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <div class="card card-wizard">
                                        <div class="card-header ">
                                            <h3 class="card-title text-center">Awesome Wizard</h3>
                                            <p class="card-category text-center">Split a complicated flow in multiple steps</p>
                                        </div>
                                        <div class="card-body ">
                                            <ul class="nav nav-tabs nav-fill" id="myTab" role="tablist">
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link active" id="inicio-tab" data-bs-toggle="tab" data-bs-target="#inicio" type="button" role="tab" aria-controls="inicio" aria-selected="true">Inicio</button>
                                                </li>
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Preguntas</button>
                                                </li>
                                                <!-- <li class="nav-item" role="presentation">
                                                    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Final</button>
                                                </li> -->
                                            </ul>
                                            <div class="tab-content" id="myTabContent">
                                                <div class="tab-pane fade show active" id="inicio" role="tabpanel" aria-labelledby="inicio-tab">
                                                    <p class="text-center">Introduce el nombre de la entrevista</p>
                                                    <div class="form-group">
                                                        <label for="">Nombre Entrevista</label>
                                                        <input type="text" class="form-control" name="nombre">
                                                        <?php echo $__env->make('alerts.feedback', ['field' => 'nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                    </div>

                                                    <div class="tab-footer">
                                                        <button type="button" class="btn btn-info btn-wd btn-next pull-right">Next</button>
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                                    <?php if (isset($component)) { $__componentOriginalf5b48299c5aa7f507a69b27f6c03df970e3f4e4c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FieldsTabs::class, ['categories' => $categories]); ?>
<?php $component->withName('fields-tabs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5b48299c5aa7f507a69b27f6c03df970e3f4e4c)): ?>
<?php $component = $__componentOriginalf5b48299c5aa7f507a69b27f6c03df970e3f4e4c; ?>
<?php unset($__componentOriginalf5b48299c5aa7f507a69b27f6c03df970e3f4e4c); ?>
<?php endif; ?>
                                                    <div class="tab-footer">
                                                        <input type="submit" class="btn btn-success pull-right btn-wd" value="Crear Guión">
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            
                                        </div>
                                        <!-- <div class="card-footer text-center">
                                            <button type="submit" class="btn btn-info btn-wd btn-next pull-right" style="d-none">Crear Formulario</button>                                            
                                            <button type="button" class="btn btn-info btn-wd btn-next pull-right">Next</button>
                                            <div class="clearfix"></div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    jQuery(function($){
        $(document).ready(function(){

            $('.btn-next').click(function(){
                $('.nav-link.active').parent().next('li').find('button').trigger('click');
            });
            $('.btn-back').click(function(){
                $('.nav-link.active').parent().prev('li').find('button').trigger('click');
            });
        }); 
    })
    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'guiones', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'empresas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/guiones/create.blade.php ENDPATH**/ ?>