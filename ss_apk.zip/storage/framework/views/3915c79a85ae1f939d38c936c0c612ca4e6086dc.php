

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card-title">Administrador de Empresas</div>
                                    <div class="card-category">Lorem Ipsum</div>
                                </div>
                                <div class="col-md-4">
                                    <a href="<?php echo e(route('empresas.create')); ?>" class="btn btn-success">Crear Empresa</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body table-full-width table-responsive">
                            <table class="table table-hover table-striped table-sortable" id="table">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>created_at</th>
                                        <!-- <th>Actions</th> -->
                                    </tr>
                                    
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <a href="<?php echo e(route('empresas.show',$empresa)); ?>"><?php echo e($empresa->nombre); ?></a></td>
                                            <td><?php echo e($empresa->created_at); ?></td>
                                            <td class="d-flex justify-content-end">
                                                <a href="<?php echo e(route('empresas.show', $empresa)); ?>" class="btn btn-info btn-link btn-xs">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('empresas.edit',$empresa)); ?>" class="btn btn-info btn-link btn-xs">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a href="" class="btn btn-info btn-link btn-xs btn-delete" id="empresa-<?php echo e($empresa->id); ?>">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                                <form action="<?php echo e(route('empresas.destroy',$empresa)); ?>" method="POST" id="delete-empresa-<?php echo e($empresa->id); ?>">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </td>
                                            <!-- <td>
                                                <div class="dropdown">
                                                    <a class="btn btn-sm btn-icon-only" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v" aria-hidden="true"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                        <a href="<?php echo e(route('empresas.edit',$empresa)); ?>" class="dropdown-item">Edit</a>
                                                        <form action="<?php echo e(route('empresas.destroy',$empresa)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                                <button type="button" class="dropdown-item" onclick="confirm('<?php echo e(__("Seguro que desea eliminar esta empresa?, todo lo relacionado con ella sera eliminado")); ?>') ? this.parentElement.submit() : ''">
                                                                <?php echo e(__('Delete')); ?>

                                                                </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </td> -->
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        jQuery(function($){
            $(document).ready(function(){
                $('.btn-delete').click(showDeleteMessage);
            });

            function showDeleteMessage(event){
                event.preventDefault();
                // console.log($(this).attr('id'));
                empresa = $(this).attr('id');
                Swal.fire({
                    title: '¿Estás seguro?',
                    // text:'No podrás revertir esto',
                    html: "<p>Estas a punto de eliminar todo lo relacionado con la empresa</p><span class='font-weight-bold'>¡No podrás revertir esto!</span>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Si, eliminalo!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Swal.fire(
                        //     'Deleted!',
                        //     'Your file has been deleted.',
                        //     'success'
                        // )
                        // console.log()
                        $('#delete-'+empresa).submit();
                    }
                })
            }
        });

        
    </script>
<?php $__env->stopPush(); ?>
<!-- onclick=" event.preventDefault();confirm('¿Desea eliminar esta empresa?') ? document.getElementById('delete-form-<?php echo e($empresa->id); ?>').submit():null;" -->
<?php echo $__env->make('layouts.app', ['activePage' => 'empresas', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'empresas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/empresas/index.blade.php ENDPATH**/ ?>