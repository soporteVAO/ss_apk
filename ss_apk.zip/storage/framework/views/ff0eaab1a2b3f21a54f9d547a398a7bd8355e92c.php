<ul class="nav nav-tabs nav-fill" id="" role="tablist">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
            <button class="nav-link <?php if($loop->first): ?> active <?php endif; ?>" data-bs-toggle="tab" data-bs-target="#<?php echo e($category->name); ?>" type="button" role="tab" aria-controls="" aira-selected="true"><?php echo e($category->name); ?></button>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<div class="tab-content" id="">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>" id="<?php echo e($category->name); ?>" role="tabpanel">
            Num Preguntas: <?php echo e(count($category->opportunityFields)); ?>

            <?php $__currentLoopData = $category->opportunityFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" value="<?php echo e($field->id); ?>" name="fields[]">
                        <span class="form-check-sign"></span>
                        <?php echo e($field->label); ?>

                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
</div>
    

    <?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/components/fields-tabs.blade.php ENDPATH**/ ?>