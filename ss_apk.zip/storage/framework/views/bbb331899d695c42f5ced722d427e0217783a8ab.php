

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row" >
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title"><?php echo e($oportunidad['opportunityName']); ?></div>
                            <div class="card-category">Editar Oportunidad</div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('oportunidades.update')); ?>" method='post'>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="row">
                                    <!-- <?php echo e(var_dump($oportunidad)); ?> -->
                                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(array_key_exists($field->systemName,$oportunidad)): ?>
                                        <div class="col-md-4">
                                            <!-- Clave: <?php echo e($field->label); ?> <br>-->
                                            <!-- Valor: <?php echo e($oportunidad[$field->systemName]); ?> <br>  -->
                                            <!-- Tipo: <?php echo e($field->dataType); ?> <br> -->
                                            <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, ['field' => $field,'value' => $oportunidad[$field->systemName]]); ?>
<?php $component->withName('Forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <input type="hidden" name="id" value="<?php echo e($oportunidad['id']); ?>">
                                <input type="submit" value="Actualizar Oportunidad" class="btn btn-success" style="">
                            </form>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'oportunidades', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'oportunidades'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/oportunidades/show.blade.php ENDPATH**/ ?>