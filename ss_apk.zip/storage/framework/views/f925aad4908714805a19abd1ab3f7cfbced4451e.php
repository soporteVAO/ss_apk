

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card stacked-form">
                                <div class="card-header ">
                                    <h4 class="card-title">Create Empresa</h4>
                                </div>
                                <div class="card-body ">
                                    <form method="post" action="<?php echo e(route('empresas.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label>Nombre Empresa</label>
                                            <input type="text" placeholder="Nombre Empresa" class="form-control" name="nombre">
                                            <?php echo $__env->make('alerts.error_self_update', ['key' => 'nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        </div>
                                        <div class="form-group">
                                            <label>Account ID SS</label>
                                            <input type="text" placeholder="Account ID" class="form-control" name="cuenta_id">
                                            <?php echo $__env->make('alerts.error_self_update', ['key' => 'cuenta_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        </div>
                                        <div class="form-group">
                                            <label>Api Key SS</label>
                                            <input type="text" placeholder="Api Key" class="form-control" name="api_key">
                                            <?php echo $__env->make('alerts.error_self_update', ['key' => 'api_key'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        </div>
                                        <input type="submit" class="btn btn-fill btn-info" value="Crear Empresa">

                                    </form>
                                </div>
                                <!-- <div class="card-footer ">
                                    <button type="submit" class="btn btn-fill btn-info">Submit</button>
                                </div> -->
                            </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['activePage' => 'empresas', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'empresas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/empresas/create.blade.php ENDPATH**/ ?>