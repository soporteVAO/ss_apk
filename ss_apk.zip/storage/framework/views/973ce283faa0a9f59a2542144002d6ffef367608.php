
<?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="form-check">
        <label class="form-check-label">
            
            <?php if($value==$option->value): ?>
                <input class="form-check-input" type="checkbox" value="<?php echo e($option->value); ?>" id="flexCheckDefault" name="<?php echo e($systemName); ?>[]" checked>
            <?php else: ?>
                <input class="form-check-input" type="checkbox" value="<?php echo e($option->value); ?>" id="flexCheckDefault" name="<?php echo e($systemName); ?>[]">
            <?php endif; ?>
            <span class="form-check-sign"></span>
            <?php echo e($option->label); ?>

        </label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/components/forms/input-checkbox.blade.php ENDPATH**/ ?>