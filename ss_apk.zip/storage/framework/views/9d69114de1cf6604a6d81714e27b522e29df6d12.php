<div class="sidebar" data-image="<?php echo e(asset('light-bootstrap/img/sidebar-5.jpg')); ?>">
    <!--
Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

Tip 2: you can also add an image using data-image tag
-->
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="https://ventasdealtooctanaje.com" class="simple-text">
                <!-- <?php echo e(__("Creative Tim")); ?> -->
                <img src="<?php echo e(asset('img/logoblanco-esq_inferior.png')); ?>" alt="" class="img-fluid w-25">
            </a>
        </div>
        <div class="user">
                    <div class="photo">
                        <img src="http://placeimg.com/640/480/people">
                    </div>
                    <div class="info">
                        
                            <a class="collapse" data-bs-toggle="collapse" href="#profilemenu" role="button" aria-expanded="false" aria-controls="collapseExample">
                                <?php echo e(Auth::user()->name); ?>

                                <div class="caret"></div>
                            </a>
                        
                        <div class="collapse" id="profilemenu">
                            <ul class="nav">
                                <li>
                                    <a class="profile-dropdown" href="<?php echo e(route('profile.index')); ?>">
                                        <span class="sidebar-mini">MP</span>
                                        <span class="sidebar-normal">My Profile</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="profile-dropdown" href="<?php echo e(route('profile.edit')); ?>">
                                        <span class="sidebar-mini">EP</span>
                                        <span class="sidebar-normal">Edit Profile</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="profile-dropdown" href="#pablo">
                                        <span class="sidebar-mini">S</span>
                                        <span class="sidebar-normal">Settings</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
        <ul class="nav">
            <li class="nav-item <?php if($activePage == 'dashboard'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="nc-icon nc-chart-pie-35"></i>
                    <p><?php echo e(__("Dashboard")); ?></p>
                </a>
            </li>
            <?php if(Auth::user()->isAdmin()): ?>
            <li class="nav-item <?php if($activePage == 'empresas'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('empresas.index')); ?>">
                    <i class="fa-regular fa-building"></i>
                    <p><?php echo e(__("Business")); ?></p>
                </a>
            </li>
            <li class="nav-item <?php if($activePage == 'users'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <i class="fa-solid fa-users"></i>
                    <p><?php echo e(__("Users")); ?></p>
                </a>
            </li>
            <?php endif; ?>
            <!-- <li class="nav-item <?php if($activePage == 'accounts'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('account.index')); ?>">
                    <i class="fa-solid fa-folder-tree"></i>
                    <p><?php echo e(__("Accounts")); ?></p>
                </a>
            </li> -->
            <li class="nav-item <?php if($activePage == 'fields'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('fields.index')); ?>">
                    <i class="fa-solid fa-table-list"></i>                    
                    <p><?php echo e(__("Fields")); ?></p>
                </a>
            </li>
            <li class="nav-item <?php if($activePage == 'oportunidades'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('oportunidades.index')); ?>">
                    <i class="fa-solid fa-handshake"></i>
                    <p><?php echo e(__("Oportunidades")); ?></p>
                </a>
            </li>
            <li class="nav-item <?php if($activePage == 'guiones'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('guiones.index')); ?>">
                    <i class="fa-solid fa-comments"></i>
                    <p><?php echo e(__("Guiones")); ?></p>
                </a>
            </li>
            
            <!-- <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#empresas_sidebar" <?php if($activeButton =='empresas'): ?> aria-expanded="true" <?php endif; ?>>
                    
                    <i class="fa-regular fa-building"></i>
                    <p>
                        <?php echo e(__('Empresas')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php if($activeButton =='empresas'): ?> show <?php endif; ?>" id="empresas_sidebar">
                    <ul class="nav">
                        <li class="nav-item <?php if($activePage == 'empresasIndex'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('empresas.index')); ?>">
                                <i class="fa-brands fa-simplybuilt"></i>
                                <i class="nc-icon nc-single-02"></i>
                                <p><?php echo e(__("All Empresas")); ?></p>
                            </a>
                        </li>
                        <li class="nav-item <?php if($activePage == 'user-management'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('empresas.create')); ?>">
                                <i class="nc-icon nc-circle-09"></i>
                                <i class="fa-regular fa-square-plus"></i>
                                <p><?php echo e(__("Create Empresa")); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li> -->
            <!-- <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#laravelExamples" <?php if($activeButton =='oportunidades'): ?> aria-expanded="true" <?php endif; ?>>
                    <i>
                        <img src="<?php echo e(asset('light-bootstrap/img/laravel.svg')); ?>" style="width:25px">
                    </i>
                    <p>
                        <?php echo e(__('Oportunidades')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php if($activeButton =='oportunidades'): ?> show <?php endif; ?>" id="laravelExamples">
                    <ul class="nav">
                        
                        <li class="nav-item <?php if($activePage == 'users'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('oportunidades.index')); ?>">
                                <i class="nc-icon nc-single-02"></i>
                                <p><?php echo e(__("All opportunitties")); ?></p>
                            </a>
                        </li>
                        <li class="nav-item <?php if($activePage == 'user-management'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                <i class="nc-icon nc-circle-09"></i>
                                <p><?php echo e(__("Create Opportunittie")); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li> -->
           
            <!-- <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#laravelExamples" <?php if($activeButton =='laravel'): ?> aria-expanded="true" <?php endif; ?>>
                    <i>
                        <img src="<?php echo e(asset('light-bootstrap/img/laravel.svg')); ?>" style="width:25px">
                    </i>
                    <p>
                        <?php echo e(__('Laravel example')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php if($activeButton =='laravel'): ?> show <?php endif; ?>" id="laravelExamples">
                    <ul class="nav">
                        <li class="nav-item <?php if($activePage == 'user'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                                <i class="nc-icon nc-single-02"></i>
                                <p><?php echo e(__("User Profile")); ?></p>
                            </a>
                        </li>
                        <li class="nav-item <?php if($activePage == 'user-management'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                <i class="nc-icon nc-circle-09"></i>
                                <p><?php echo e(__("User Management")); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li> -->

            <!-- <li class="nav-item <?php if($activePage == 'table'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('page.index', 'table')); ?>">
                    <i class="nc-icon nc-notes"></i>
                    <p><?php echo e(__("Table List")); ?></p>
                </a>
            </li>
            <li class="nav-item <?php if($activePage == 'typography'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('page.index', 'typography')); ?>">
                    <i class="nc-icon nc-paper-2"></i>
                    <p><?php echo e(__("Typography")); ?></p>
                </a>
            </li>
            <li class="nav-item <?php if($activePage == 'icons'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('page.index', 'icons')); ?>">
                    <i class="nc-icon nc-atom"></i>
                    <p><?php echo e(__("Icons")); ?></p>
                </a>
            </li>
            <li class="nav-item <?php if($activePage == 'maps'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('page.index', 'maps')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p><?php echo e(__("Maps")); ?></p>
                </a>
            </li>
            <li class="nav-item <?php if($activePage == 'notifications'): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('page.index', 'notifications')); ?>">
                    <i class="nc-icon nc-bell-55"></i>
                    <p><?php echo e(__("Notifications")); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active bg-danger" href="<?php echo e(route('page.index', 'upgrade')); ?>">
                    <i class="nc-icon nc-alien-33"></i>
                    <p><?php echo e(__("Upgrade to PRO")); ?></p>
                </a>
            </li> -->
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>