



<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header"></div>
                        <div class="card-body">
                            <form action="<?php echo e(route('oportunidades.update')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($oportunidad_id); ?>">
                                <div class="entrevista-carousel">
                                    <?php $__currentLoopData = $guion->getOrderedFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <div class="card <?php echo e($field->category->name); ?> mx-3">
                                                <div class="card-body">
                                                    <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, ['field' => $field]); ?>
<?php $component->withName('Forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                                                
                                                    <div class="slider-buttons">
                                                        <button type="button" class="btn btn-success ml-auto prev-slide">Prev</button>
                                                        <button type="button" class="btn btn-success ml-auto next-slide <?php if($loop->last): ?> d-none <?php endif; ?>">Next</button>
                                                        <?php if($loop->last): ?>
                                                            <input type="submit" class="btn btn-success" value="Actualizar Datos">
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        jQuery(function($){
            $('.entrevista-carousel').slick({
                'arrows': true,
                'infinite':false,
                'nextArrow':$('.entrevista-carousel button.btn.next-slide'),
                'prevArrow': $('.entrevista-carousel button.btn.prev-slide')
            });
        })
        
        // $('.entrevista-carousel button.btn.next-slide').slick('nextSlide');
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'guiones', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'empresas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/guiones/entrevista-oportunidad.blade.php ENDPATH**/ ?>