

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card data-tables">

                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card-title">Users</div>
                                    <div class="card-category">Lorem Ipsum</div>
                                </div>
                                <div class="col-md-4">
                                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success">Crear Usuario</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 mt-2">
                        </div>

                        <div class="toolbar">
                            <!--Here you can write extra buttons/actions for the toolbar-->
                        </div>
                        <div class="card-body table-full-width table-responsive">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Empresa</th>
                                        <th>SS ID</th>
                                        <th>Start</th>
                                        <th>Rol</th>
                                        <!-- <th>Actions</th> -->
                                    </tr>
                                </thead>
                                <!-- <tfoot>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Empresa</th>
                                        <th>Start</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot> -->
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="<?php echo e(route('users.show', $user)); ?>"><?php echo e($user->name); ?></a></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($user->empresa->nombre); ?></td>
                                            <td class="<?php if(!$user->ss_id): ?> alert-warning <?php endif; ?>"><?php echo e($user->ss_id); ?></td>
                                            <td><?php echo e($user->created_at); ?></td>
                                            <td><?php echo e($user->role->name); ?></td>
                                            <td class="d-flex justify-content-end">
                                                <a href="<?php echo e(route('users.show', $user)); ?>" class="btn btn-info btn-link btn-xs">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('users.edit',$user)); ?>" class="btn btn-info btn-link btn-xs" >
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a href="" class="btn btn-info btn-link btn-xs btn-delete" id="user-<?php echo e($user->id); ?>">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                                <form action="<?php echo e(route('users.delete',$user)); ?>" method="POST" id="delete-user-<?php echo e($user->id); ?>">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        jQuery(function($){
            $(document).ready(function(){
                $('.btn-delete').click(showDeleteMessage);
            });
        });

        function showDeleteMessage(event){
            event.preventDefault();
            // console.log($(this).attr('id'));
            user = $(this).attr('id');
            Swal.fire({
                title: '¿Estás seguro?',
                // text:'No podrás revertir esto',
                html: "<p>Estas a punto de eliminar todo lo relacionado con el usuario</p><span class='font-weight-bold'>¡No podrás revertir esto!</span>",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '¡Si, eliminalo!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Swal.fire(
                    //     'Deleted!',
                    //     'Your file has been deleted.',
                    //     'success'
                    // )
                    // console.log()
                    $('#delete-'+user).submit();
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'users', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Icons', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/users/index.blade.php ENDPATH**/ ?>