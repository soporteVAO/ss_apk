
<div class="mb-3 form-group">
    <label for="exampleFormControlInput1" class="form-label"><?php echo e($field->label); ?></label>
    <?php if($field->dataType=='int'): ?>
        <input type="number" name="<?php echo e($field->systemName); ?>" class="form-control" id="exampleFormControlInput1" placeholder="" value="<?php echo e($value); ?>">
    <?php elseif($field->dataType=='text'): ?>
        <input type="text" name="<?php echo e($field->systemName); ?>" class="form-control" id="exampleFormControlInput1" placeholder="" value="<?php echo e($value); ?>">
    <?php elseif($field->dataType=='boolean'): ?>
        <?php if (isset($component)) { $__componentOriginal8910c4a257973ab4112e9428f064f5405f70bb17 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\InputBoolean::class, ['value' => $value,'systemName' => $field->systemName]); ?>
<?php $component->withName('Forms.InputBoolean'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8910c4a257973ab4112e9428f064f5405f70bb17)): ?>
<?php $component = $__componentOriginal8910c4a257973ab4112e9428f064f5405f70bb17; ?>
<?php unset($__componentOriginal8910c4a257973ab4112e9428f064f5405f70bb17); ?>
<?php endif; ?>
    <?php elseif($field->dataType=='date'): ?>
        <!-- <input type="datetime" name="<?php echo e($field->systemName); ?>" class="form-control" id="exampleFormControlInput1" placeholder="" value="<?php echo e($value); ?>">     -->
    <?php elseif($field->dataType=='checkbox'): ?>
        <?php if (isset($component)) { $__componentOriginala98985570065d4cb1f37b1df486f0884932b8068 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\InputCheckbox::class, ['value' => $value,'systemName' => $field->systemName,'options' => $field->options]); ?>
<?php $component->withName('Forms.InputCheckbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala98985570065d4cb1f37b1df486f0884932b8068)): ?>
<?php $component = $__componentOriginala98985570065d4cb1f37b1df486f0884932b8068; ?>
<?php unset($__componentOriginala98985570065d4cb1f37b1df486f0884932b8068); ?>
<?php endif; ?>
    <?php elseif($field->dataType=='picklist'): ?>
        <?php if (isset($component)) { $__componentOriginalaa9e2e00dcec6b58db49b9128f7191370bc93381 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Select::class, ['value' => $value,'systemName' => $field->systemName,'options' => $field->options]); ?>
<?php $component->withName('Forms.Select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa9e2e00dcec6b58db49b9128f7191370bc93381)): ?>
<?php $component = $__componentOriginalaa9e2e00dcec6b58db49b9128f7191370bc93381; ?>
<?php unset($__componentOriginalaa9e2e00dcec6b58db49b9128f7191370bc93381); ?>
<?php endif; ?>
    <?php elseif($field->dataType=='textarea'): ?>
        <textarea name="<?php echo e($field->systemName); ?>" id="" cols="30" rows="20" class="form-control"></textarea>
    <?php elseif($field->dataType=='upload'): ?>

    <?php else: ?>
        <input type="text" class="form-control" id="" name="<?php echo e($field->systemName); ?>" placeholder="" value="<?php echo e($value); ?>">
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/components/forms/input.blade.php ENDPATH**/ ?>