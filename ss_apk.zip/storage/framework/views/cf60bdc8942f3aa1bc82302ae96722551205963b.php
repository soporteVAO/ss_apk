

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="section-image">
                <!--   you can change the color of the filter page using: data-color="blue | purple | green | orange | red | rose " -->
                <div class="row">

                    <div class="card col-md-8">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="card-title"><?php echo e(__('View Profile')); ?></h3>
                                </div>
                                <div class="col-4">
                                    <a href="<?php echo e(route('users.edit',$user)); ?>" class="btn btn-success">Editar</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('User information')); ?></h6>
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="">
                                        <i class="fa fa-user"></i><?php echo e(__('Name')); ?>

                                    </label>
                                    <p><?php echo e($user->name); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="">
                                        <i class="fa fa-envelope-o"></i><?php echo e(__('Email')); ?>

                                    </label>

                                    <p><?php echo e($user->email); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <label class="">
                                        <i class="fa fa-envelope-o"></i><?php echo e(__('SS Id')); ?>

                                    </label>
                                    <?php if($user->ss_id): ?>
                                        <p><?php echo e($user->ss_id); ?></p>
                                    <?php else: ?>
                                        <div class="alert alert-warning">Actualice su perfil para obtener su ID</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="">
                                        <i class="fa-regular fa-building"></i><?php echo e(__('Company Name')); ?>

                                    </label>

                                    <p><?php echo e($user->empresa->nombre); ?></p>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="card-image">
                                <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="...">
                            </div>
                            <div class="card-body">
                                <div class="author">
                                    <a href="#">
                                        <img class="avatar border-gray" src="<?php echo e(asset('light-bootstrap/img/faces/face-3.jpg')); ?>" alt="...">
                                        <h5 class="title"><?php echo e(__('Mike Andrew')); ?></h5>
                                    </a>
                                    <p class="description">
                                        <?php echo e(__('michael24')); ?>

                                    </p>
                                </div>
                                <p class="description text-center">
                                <?php echo e(__(' "Lamborghini Mercy')); ?>

                                    <br> <?php echo e(__('Your chick she so thirsty')); ?>

                                    <br> <?php echo e(__('I am in that two seat Lambo')); ?>

                                </p>
                            </div>
                            <hr>
                            <div class="button-container mr-auto ml-auto">
                                <button href="#" class="btn btn-simple btn-link btn-icon">
                                    <i class="fa fa-facebook-square"></i>
                                </button>
                                <button href="#" class="btn btn-simple btn-link btn-icon">
                                    <i class="fa fa-twitter"></i>
                                </button>
                                <button href="#" class="btn btn-simple btn-link btn-icon">
                                    <i class="fa fa-google-plus-square"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'users', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'User Profile', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/users/show.blade.php ENDPATH**/ ?>