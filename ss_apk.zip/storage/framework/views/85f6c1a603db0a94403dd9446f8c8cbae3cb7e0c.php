
<select class="form-select" aria-label="Default select example" name="<?php echo e($systemName); ?>">
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->iteration==1 && is_null($value)): ?>
                
        <?php endif; ?>
        <option value="<?php echo e($option->value); ?>"><?php echo e($option->label); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/components/forms/select.blade.php ENDPATH**/ ?>