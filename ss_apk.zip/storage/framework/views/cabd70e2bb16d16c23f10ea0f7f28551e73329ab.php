


<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card-title">Edit Guion</div>
                                    <div class="card-category">Lorem Ipsum</div>
                                </div>
                                <div class="col-md-4">
                                    <a href="<?php echo e(route('guiones.create')); ?>" class="btn btn-success">Crear Guión</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('guiones.update', $guion)); ?>" method="post" id="form">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="">Nombre</label>
                                    <input type="text" value="<?php echo e($guion->nombre); ?>" class="form-control" name="nombre">
                                </div>
                                <div class="draggable-items" id="sortable">
                                    <label for="">Fields Order</label>
                                    <?php $__currentLoopData = $guion->getOrderedFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group alert alert-<?php echo e($field->category->name); ?>">
                                            <input class="form-control draggable" name="order[]" value="<?php echo e($field->label); ?>" disabled>
                                            <button type="button" class="btn btn-xs btn-delete"><i class="fa fa-times"></i></button>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- <input type="submit" class="btn btn-success" value="Actualizar Guión"> -->
                                <button type="button" class="btn btn-success send-request">
                                    <?php echo e(__('Update Guion')); ?>

                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js" integrity="sha512-zYXldzJsDrNKV+odAwFYiDXV2Cy37cwizT+NkuiPGsa9X1dOz04eHvUWVuxaJ299GvcJT31ug2zO4itXBjFx4w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        jQuery(function($){
            $(document).ready(function(){
                sortable = new Sortable(document.getElementById('sortable'));
                $('button[type="button"].send-request').click(()=> {
                    $('#sortable input').each(function (){
                        // console.log($(this));
                        $(this).removeAttr('disabled');
                    });
                    // console.log($(this));
                    $('#form').submit();
                    // this.parentElement.submit()
                });
                
                //script para eliminar preguntas
                $("button.btn-delete").click(function(){
                    // console.log($(this).parent())
                    $(this).parent().remove();
                })
            })
        })
        
    </script>
    <!-- <script>
        const draggables = document.querySelectorAll('.draggable');
        const container = document.querySelectorAll('draggable-items');
        // console.log(draggables);
        draggables.forEach(draggable => {
            // console.log(draggable);
            draggable.addEventListener('dragStart', ()=> {
                console.log('dragStart');
                draggable.classList.add('dragging');
            });
        });
    </script> -->
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'guiones', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'empresas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/guiones/edit.blade.php ENDPATH**/ ?>