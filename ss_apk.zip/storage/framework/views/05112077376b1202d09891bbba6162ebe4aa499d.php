


<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">

            </div>
            <div class="card-body">
                <form action="<?php echo e(route('entrevista.oportunidad',$guion)); ?>" method="get">  
                    <div class="entrevista-carousel">
                        <div>
                            <div class="card">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="">Introduzca el identificador de la oportunidad</label>
                                        <input type="text" name="opportunity_id" class="form-control">
                                    </div>
                                    <input type="submit" class="btn btn-success" value="Iniciar Entrevista">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['activePage' => 'guiones', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'empresas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/guiones/entrevista.blade.php ENDPATH**/ ?>