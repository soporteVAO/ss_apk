

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card-title">Guiones</div>
                                    <div class="card-category">Lorem Ipsum</div>
                                </div>
                                <div class="col-md-4">
                                    <a href="<?php echo e(route('guiones.create')); ?>" class="btn btn-success">Crear Guión</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body table-full-width table-responsive">
                            <table class="table table-hover table-striped table-sortable" id="table">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>created_at</th>
                                        <th></th>
                                        <!-- <th>Actions</th> -->
                                    </tr>
                                    
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $guiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($guion->nombre); ?></td>
                                            <td><?php echo e($guion->created_at); ?></td>
                                            <td><a href="<?php echo e(route('startEntrevista',$guion)); ?>" class="btn btn-success"><i class="fa-solid fa-circle-play"></i></a></td>
                                            <td class="text-right">
                                                <a href="<?php echo e(route('guiones.show',$guion)); ?>" class="btn btn-info btn-link btn-xs">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('guiones.edit',$guion)); ?>" class="btn btn-info btn-link btn-xs">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a href="" class="btn btn-info btn-link btn-xs btn-delete" id="form-<?php echo e($guion->id); ?>">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                                <form action="<?php echo e(route('guiones.destroy',$guion)); ?>" method="POST" id="delete-form-<?php echo e($guion->id); ?>">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    jQuery(function($){
        $(document).ready(function(){
            $("#table").fancyTable({
              sortColumn:0,
              searchable: false,
            //   pagination: true,
            //   perPage:10,
              globalSearch:true
          });
          $('.btn-delete').click(showDeleteMessage);

        });
        function showDeleteMessage(event){
            event.preventDefault();
            // console.log($(this).attr('id'));
            guion = $(this).attr('id');
            Swal.fire({
                title: '¿Estás seguro?',
                // text:'No podrás revertir esto',
                html: "<p>Estas a punto de eliminar todo lo relacionado con el usuario</p><span class='font-weight-bold'>¡No podrás revertir esto!</span>",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '¡Si, eliminalo!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Swal.fire(
                    //     'Deleted!',
                    //     'Your file has been deleted.',
                    //     'success'
                    // )
                    // console.log()
                    $('#delete-'+guion).submit();
                }
            })
        }
    })
    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'guiones', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Dashboard', 'activeButton' => 'empresas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss_apk\resources\views/guiones/index.blade.php ENDPATH**/ ?>